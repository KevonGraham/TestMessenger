package ClientController;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class TestClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		TestClient socket=new TestClient();
		
		socket.Run();
		
	}

	
	public void Run() throws Exception
	{
		Socket Sock= new Socket("localhost",400);
		
		PrintStream PS= new PrintStream(Sock.getOutputStream());
		PS.println("Yo Server this is a Client Server");
		
		InputStreamReader IR= new InputStreamReader(Sock.getInputStream());
		BufferedReader BR = new BufferedReader(IR);
		
		String Message = BR.readLine();
		System.out.println(Message);
		
		Sock.close();
	}
	

	
	
	
}
